#define OLC_PGE_APPLICATION
#include "olcPixelGameEngine.h"

class Example : public olc::PixelGameEngine
{
public:
	Example()
	{
		sAppName = "Example";
	}

public:
	bool OnUserCreate() override
	{
		playerX = 100.0f;
		playerY = 100.0f;
		return true;
	}

	bool OnUserUpdate(float fElapsedTime) override
	{
		if (GetKey(olc::Key::A).bPressed) {
			playerX -= 5.0f;
		}
		if (GetKey(olc::Key::D).bPressed) {
			playerX += 5.0f;
		}
		if (GetKey(olc::Key::W).bPressed) {
			playerY -= 5.0f;
		}
		if (GetKey(olc::Key::S).bPressed) {
			playerY += 5.0f;
		}
		DrawRect((int)playerX, (int)playerY, 2, 2, olc::YELLOW);
		return true;
	}
private:
	float playerX;
	float playerY;
};

int main()
{
	Example demo;
	if (demo.Construct(256, 240, 4, 4))
		demo.Start();
	return 0;
}